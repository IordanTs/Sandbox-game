﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIDE_3_motorbike_game
{
    class Fighter
    {
        public int attack;
        public int shield;
        public int health;
        public int cycle;
        public string name;

        public Fighter(int a, int s, int h, int c, string n)
        {
            this.attack = a;
            this.shield = s;
            this.health = h;
            this.cycle = c;
            this.name = n;
        }

        public int WonBattles(int h, int s)
        {
            int won = 0;
            won = h + s;
            return won;
        }

        public void XP(int a, int c)
        {
            int xp = a + c;
            Console.WriteLine("Knight's XP = " + xp);
        }

        public void Show()
        {
            Console.WriteLine();
            Console.Write(" Name = " + name);
            Console.Write(" Cycle = " + cycle);
            Console.Write(" Attack = " + attack);
            Console.Write(" Shield = " + shield);
            Console.Write(" Health = " + health);
            Console.WriteLine();
        }
    }
}
