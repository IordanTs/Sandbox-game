﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIDE_3_motorbike_game.Game
{
    class GameMechanics
    {
        static int limit(int n)
        {
            int result = 0;
            bool flag = false;
            do
            {
                n = int.Parse(Console.ReadLine());
                if (n > 0 && n <= 100)
                {
                    result = n;
                    flag = true;
                }
                else
                {
                    throw new Exception("The value should be in range from 0 to 100");
                }
            }
            while (flag == false);
            return result;
        }
        static void Fight(List<Fighter> g)
        {
            string name = g[0].name;
            string name1 = g[1].name;
            int a1; int a2; int h1, h2;
            bool flag = false;
            a1 = g[0].attack;
            h1 = g[0].health + g[0].shield;
            a2 = g[1].attack;
            h2 = g[1].health + g[1].shield;
            while (flag == false)
            {
                if (a1 > h2)
                {
                    Console.WriteLine("{0} wins",name);
                    g[0].cycle++;
                    flag = true;
                    break;
                }
                else
                {
                    h2 = h2 - a1;
                }
                if (a2 > h1)
                {
                    Console.WriteLine("{0} wins!", name1);
                    g[1].cycle++;
                    flag = true;
                    break;
                }
                else
                {
                    h1 = h1 - a2;
                }
            }
        }
        public void StartGame()
        {
            Console.Clear();
            List<Fighter> twin = new List<Fighter>();
            for (int i = 1; i <= 2; i++)
            {
                Console.Write("Enter Knight Name: "); string name = Console.ReadLine();
                Console.Write("Enter cycle - won battles: "); int cycle = 0; cycle = limit(cycle);
                Console.Write("Enter attack: "); int attack = 0; attack = limit(attack);
                Console.Write("Enter shield: "); int shield = 0; shield = limit(shield);
                Console.Write("Enter Health: "); int health = 0; health = limit(health);
                Console.WriteLine();
                if (i == 1)
                {
                    Knight1 k1 = new Knight1(attack, shield, health, cycle, name);
                    twin.Add(k1);
                }
                else
                {
                    Knight2 k2 = new Knight2(attack, shield, health, cycle, name);
                    twin.Add(k2);
                }
            }
            foreach (Fighter el in twin)
            {
                el.Show();
                el.WonBattles(el.health, el.shield);
                el.XP(el.attack, el.cycle);
            }
            Console.WriteLine();
            Fight(twin);
            Console.WriteLine();
            foreach (Fighter el in twin)
            {
                el.Show();
                el.WonBattles(el.health, el.shield);
                el.XP(el.attack, el.cycle);
            }
        }
    }
}
