﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIDE_3_motorbike_game.Game
{
    class Knight1 : Fighter
    {
        public Knight1(int a, int s, int h, int c, string n) : base(a, s, h, c, n)
        {
        }
    }
    class Knight2 : Fighter
    {
        public Knight2(int a, int s, int h, int c, string n) : base(a, s, h, c, n)
        {
        }
    }
}
