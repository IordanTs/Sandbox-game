﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using RIDE_3_motorbike_game.Variables;

namespace RIDE_3_motorbike_game.Information
{
    class FighterData
    {
        const string _sqlConnectionString = "Data Source=DESKTOP-4NAAFRM;Initial Catalog=Userdata;Integrated Security=True";
        List<FightVariables> list = new List<FightVariables>();
        SqlConnection connection = new SqlConnection(_sqlConnectionString);
        public List<FightVariables> FightTable()
        {
            connection.Open();
            string table = "SELECT [id], [UserId], [CharacterName], [AttackPoints],[DefencePoints],[HealthPoints], [DateCreated] FROM Fighters";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {

                            FightVariables variable = new FightVariables()
                            {
                                Id = datareader.GetInt32(0),
                                UserId = datareader.GetInt32(1),
                                CharacterName = datareader.GetString(2),
                                AttackPoints = datareader.GetInt32(4),
                                DefencePoints = datareader.GetInt32(5),
                                HealthPoints = datareader.GetInt32(6),
                                DateCreated = datareader.GetDateTime(7)
                            };
                            list.Add(variable);
                        }
                    }
                    else
                    {
                        list = null;
                    }
                }
            }
            return list;
        }
        public void SaveFighter(FightVariables variables)
        {
            connection.Open();
            string table = "insert into Fighters([ID], [UserId], [CharacterName], [AttackPoints], [DefencePoints], [HealthPoints], [DateCreated])values(@ID, @UserId, @CharacterName, @AttackPoints, @DefencePoints, @HealthPoints, @DateCreated)";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                command.Parameters.Add("@ID", System.Data.SqlDbType.Int).Value = variables.Id;
                command.Parameters.Add("@UserId", System.Data.SqlDbType.Int).Value = variables.UserId;
                command.Parameters.Add("@CharacterName", System.Data.SqlDbType.NVarChar).Value = variables.CharacterName;
                command.Parameters.Add("@AttackPoints", System.Data.SqlDbType.Int).Value = variables.AttackPoints;
                command.Parameters.Add("@DefencePoints", System.Data.SqlDbType.Int).Value = variables.DefencePoints;
                command.Parameters.Add("@HealthPoints", System.Data.SqlDbType.Int).Value = variables.HealthPoints;
                command.Parameters.Add("@DateCreated", System.Data.SqlDbType.DateTime).Value = variables.DateCreated;
                object result = command.ExecuteNonQuery();
            }
            Console.WriteLine("Connection Successfuly!");
            Console.WriteLine("Press eney key to continue :)");
            Console.ReadKey(true);
        }
        public int FightersTable()
        {
            int id = 0;
            connection.Open();
            string table = "SELECT [id], [UserId], [CharacterName], [AttackPoints], [DefencePoints], [HealthPoints], [DateCreated] FROM Fighters";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {
                            id++;
                        }
                    }
                    else
                    {
                        id = 0;
                    }
                }
            }
            return id;
        }
    }
}
