﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using RIDE_3_motorbike_game.Variables;
using RIDE_3_motorbike_game.View;

namespace RIDE_3_motorbike_game.Information.Fight
{
    class MainDataForFight
    {
        const string _sqlConnectionString = "Data Source=DESKTOP-4NAAFRM;Initial Catalog=Userdata;Integrated Security=True";
        List<FightVariables> list = new List<FightVariables>();
        SqlConnection connection = new SqlConnection(_sqlConnectionString);
        public List<FightVariables> FightTable()
        {
            connection.Open();
            string table = "SELECT [id], [UserId], [CharacterName], [AttackPoints],[DefencePoints],[HealthPoints], [DateCreated] FROM Fighters";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {

                            FightVariables variable = new FightVariables()
                            {
                                Id = datareader.GetInt32(0),
                                UserId = datareader.GetInt32(1),
                                CharacterName = datareader.GetString(2),
                                AttackPoints = datareader.GetInt32(3),
                                DefencePoints = datareader.GetInt32(4),
                                HealthPoints = datareader.GetInt32(5),
                                DateCreated = datareader.GetDateTime(6)
                            };
                            list.Add(variable);
                        }
                    }
                    else
                    {
                        list = null;
                    }
                }
            }
            return list;
        }
        public void SaveFighter(FightVariables variables)
        {
            connection.Open();
            string table = "insert into Fighters([ID], [UserId], [CharacterName], [AttackPoints], [DefencePoints], [HealthPoints], [DateCreated])values(@ID, @UserId, @CharacterName, @AttackPoints, @DefencePoints, @HealthPoints, @DateCreated)";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                command.Parameters.Add("@ID", System.Data.SqlDbType.Int).Value = variables.Id;
                command.Parameters.Add("@UserId", System.Data.SqlDbType.Int).Value = variables.UserId;
                command.Parameters.Add("@CharacterName", System.Data.SqlDbType.NVarChar).Value = variables.CharacterName;
                command.Parameters.Add("@AttackPoints", System.Data.SqlDbType.Int).Value = variables.AttackPoints;
                command.Parameters.Add("@DefencePoints", System.Data.SqlDbType.Int).Value = variables.DefencePoints;
                command.Parameters.Add("@HealthPoints", System.Data.SqlDbType.Int).Value = variables.HealthPoints;
                command.Parameters.Add("@DateCreated", System.Data.SqlDbType.DateTime).Value = variables.DateCreated;
                object result = command.ExecuteNonQuery();
            }
            Console.WriteLine();
            Console.WriteLine("Connection Successfuly!");
            Console.WriteLine("Press eney key to continue :)");
            Console.ReadKey(true);
        }
        public int FightersTable()
        {
            int id = 0;
            connection.Open();
            string table = "SELECT [id], [UserId], [CharacterName], [AttackPoints], [DefencePoints], [HealthPoints], [DateCreated] FROM Fighters";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {
                            id++;
                        }
                    }
                    else
                    {
                        id = 0;
                    }
                }
            }
            return id;
        }
        public void FighterViewTable()
        {
            ViewForUserAfterLogIn view = new ViewForUserAfterLogIn();
            var objeckt = FightTable();
            foreach (FightVariables variable in objeckt)
            {
                Console.WriteLine("Id:{0} ------- UserId: {1} ------- Character Name: {2} ------- Attack Points: {3} ------- DefencePoints: {4} ------- HealthPoints: {5} ------- Date of registration: {6}",
                    variable.Id.ToString(),
                    variable.UserId.ToString(),
                    variable.CharacterName.ToString(),
                    variable.AttackPoints.ToString(),
                    variable.DefencePoints.ToString(),
                    variable.HealthPoints.ToString(),
                    variable.DateCreated.ToString(@"yyyy MM dd"));
                Console.WriteLine("*****************************************************************************************************************************************************************************");
            }
            Console.WriteLine();
            Console.WriteLine("E[x]it");
            Console.Write("> ");
            string userchoise = Console.ReadLine();
            switch (userchoise)
            {
                case "x":
                    {
                        Console.Clear();
                        view.UserView();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid command");
                        Console.WriteLine("Press eney key to continue :)");
                        Console.ReadKey(true);
                        Console.Clear();
                        MainDataForFight fight = new MainDataForFight();
                        fight.FighterViewTable();
                        return;
                    }
            }
        }

        public void UserFighters(int id)
        {
            List<FightVariables> objeckt = new List<FightVariables>();
            objeckt = FightTable();
            foreach (FightVariables variable in objeckt)
            {
                if (variable.UserId == id)
                {
                    Console.WriteLine("id: {0} User id: {1} Character name: {2}, AttackPoints: {3}, Defence(Shield) points {4}, Health points {5}, Date created: {6}",
                        variable.Id.ToString(),
                        variable.UserId.ToString(),
                        variable.CharacterName,
                        variable.AttackPoints.ToString(),
                        variable.DefencePoints.ToString(),
                        variable.HealthPoints.ToString(),
                        variable.DateCreated.ToString(@"yyyy MM dd"));
                }
                else if (objeckt == null)
                {
                    Console.WriteLine("You have no fighters.");
                }
            }
            Console.WriteLine();
            Console.WriteLine("Connection Successfuly!");
            Console.WriteLine("Press eney key to continue :)");
            Console.ReadKey(true);
        }
        public int Fighters(int id, int input)
        {
            List<FightVariables> objeckt = new List<FightVariables>();
            objeckt = FightTable();
            List<int> IDs = new List<int>();
            foreach (FightVariables variables in objeckt)
            {
                if (variables.UserId == id)
                {
                    Console.WriteLine("id: {0} User id: {1} Character name: {2}, AttackPoints: {3}, Defence(Shield) points {4}, Health points {5}, Date created: {6}",
                        variables.Id.ToString(),
                        variables.UserId.ToString(),
                        variables.CharacterName,
                        variables.AttackPoints.ToString(),
                        variables.DefencePoints.ToString(),
                        variables.HealthPoints.ToString(),
                        variables.DateCreated.ToString(@"yyyy MM dd"));
                    IDs.Add(variables.Id);
                }
            }
            bool flag1 = false;
            do
            {
                Console.WriteLine("Enter the id of the fighter...");
                input = int.Parse(Console.ReadLine());
                foreach (int el in IDs)
                {
                    if (el == input)
                    {
                        flag1 = true;
                        break;
                    }
                    else
                    {
                        flag1 = false;
                    }
                }
            }
            while (flag1 == false);
            return input;
        }
        private int checkPo(int n)
        {
            bool f = false;
            do
            {
                Console.WriteLine("Enter value between 0 and 100");
                n = int.Parse(Console.ReadLine());
                if (n > 0 && n <= 100)
                {
                    f = true;
                }
                else
                {
                    Console.Write("Error. The value should be within the range.");
                    f = false;
                }
            }
            while (f == false);
            return n;
        }
        //public void DeleteFighter(int id)
        //{

        //    bool flag = false;
        //    int input = 0;
        //    while (flag == false)
        //    {
        //        input = Fighters(id, input);
        //        using (SqlConnection con = new SqlConnection(_sqlConnectionString))
        //        {
        //            con.Open();
        //            using (SqlCommand command = new SqlCommand("DELETE FROM Fighters WHERE id = '" + input + "'", con))
        //            {
        //                command.ExecuteNonQuery();
        //            }
        //            con.Close();
        //        }
        //        Console.WriteLine("Operation Successfull.");
        //        flag = true; break;
        //    }
        //}
        //public void EditFighter(int userid)
        //{
        //    bool flag = false;
        //    int input = 0;
        //    while (flag == false)
        //    {
        //        input = Fighters(userid, input);
        //        EditFuncMenu(input);
        //        Console.WriteLine("Operation Successfull.");
        //        flag = true; break;
        //    }
        //}
        //private void EditFuncMenu(int input)
        //{
        //    string info2 = "";
        //    int ap = 0;
        //    Console.WriteLine("Enter Attack points.");
        //    ap = checkPo(ap);
        //    Console.WriteLine("Enter Defence points.");
        //    int dp = 0;
        //    dp = checkPo(dp);
        //    Console.WriteLine("Enter Health points");
        //    int hp = 0;
        //    hp = checkPo(hp);
        //    connection.Open();
        //    string q = "Update fighter set ', AttackPoints = '" + ap + "', DefencePoints = '" + dp + "', HealthPoints = '" + hp + "' Where id = '" + input + "'";
        //    using (SqlCommand com = new SqlCommand(q, connection))
        //    {

        //        object result = com.ExecuteNonQuery();
        //    }
        //    Console.WriteLine("Operation Successful!");
        //    Console.WriteLine("Press any key.");
        //}
    }
}
