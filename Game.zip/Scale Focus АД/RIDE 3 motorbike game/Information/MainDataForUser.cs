﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using RIDE_3_motorbike_game.Variables;
using RIDE_3_motorbike_game.View;


namespace RIDE_3_motorbike_game.Information
{
    class MainDataForUser
    {
        const string _sqlConnectionString = "Data Source=DESKTOP-4NAAFRM;Initial Catalog=Userdata;Integrated Security=True";
        List<UserVariables> list = new List<UserVariables>();
        SqlConnection connection = new SqlConnection(_sqlConnectionString);
        public List<UserVariables> UserTable()
        {
            connection.Open();
            string table = "SELECT [id], [Username], [Password], [UserRole], [DateCreated] FROM Users";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {
                            UserVariables userdata = new UserVariables()
                            {
                                Id = datareader.GetInt32(0),
                                UserName = datareader.GetString(1),
                                UserPassword = datareader.GetString(2),
                                UserRole = datareader.GetString(3),
                                DateCreated = datareader.GetDateTime(4).Date
                            };
                            list.Add(userdata);
                        }
                    }
                    else
                    {
                        list = null;
                    }
                }
            }
            return list;
        }
        public void SaveUser(UserVariables variables)
        {

            connection.Open();
            string table = "insert into Users([id], [Username], [Password], [UserRole], [DateCreated])values(@id, @Username, @Password, @UserRole, @DateCreated)";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = variables.Id;
                command.Parameters.Add("@Username", System.Data.SqlDbType.NVarChar).Value = variables.UserName;
                command.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar).Value = variables.UserPassword;
                command.Parameters.Add("@UserRole", System.Data.SqlDbType.NVarChar).Value = variables.UserRole;
                command.Parameters.Add("@DateCreated", System.Data.SqlDbType.DateTime).Value = variables.DateCreated;
                object result = command.ExecuteNonQuery();
            }
            Console.WriteLine("Connection Successfuly!");
            Console.WriteLine("Press eney key to continue :)");
            Console.ReadKey(true);
        }
        public int Table()
        {
            int id = 0;
            connection.Open();
            string table = "SELECT [id], [Username], [Password], [UserRole], [DateCreated] FROM Users";
            using (SqlCommand command = new SqlCommand(table, connection))
            {
                using (SqlDataReader datareader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                {
                    if (datareader.HasRows)
                    {
                        while (datareader.Read())
                        {
                            id++;
                        }
                    }
                    else
                    {
                        id = 0;
                    }
                }
            }
            return id;
        }
        public void UserViewTable()
        {
            ViewForUserAfterLogIn view = new ViewForUserAfterLogIn();
            var objeckt = UserTable();
            foreach (UserVariables variable in objeckt)
            {
                Console.WriteLine("Id:{0} ------- Username: {1} ------- Role: {2} ------- Date of registration: {3}",
                    variable.Id.ToString(),
                    variable.UserName.ToString(),
                    variable.UserRole.ToString(),
                    variable.DateCreated.ToString(@"yyyy MM dd"));
                Console.WriteLine("***************************************************************************************************");
            }
            Console.WriteLine();
            Console.WriteLine("E[x]it");
            Console.Write("> ");
            string userchoise = Console.ReadLine();
            switch (userchoise)
            {
                case "x":
                    {
                        Console.Clear();
                        view.UserView();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid command");
                        Console.WriteLine("Press eney key to continue :)");
                        Console.ReadKey(true);
                        Console.Clear();
                        MainDataForUser usertable = new MainDataForUser();
                        usertable.UserViewTable();
                        return;
                    }
            }
        }
        public int IdAndAllData(string Username, string Password)
        {
            int returnn = -1;
            int count = Table();
            var basse = UserTable();
            if (basse == null)
            {
                Console.WriteLine("NO DATA!!!");
            }
            else
            {
                for (int i = 0; i < count; i++)
                {
                    if (string.Equals(Username, basse[i].UserName) && string.Equals(Password, basse[i].UserPassword.ToString()))
                    {
                        returnn = i + 1;
                        i = count - 1;
                    }
                    else
                    {
                       
                    }
                }
            }
            return returnn;
        }
        public int UserDelete(int id, int input)
        {
            List<UserVariables> basse = new List<UserVariables>();
            basse = UserTable();
            List<int> IDs = new List<int>();
            foreach (UserVariables variable in basse)
            {
                if (variable.Id == id)
                {
                    Console.WriteLine("Id:{0} ------- Username: {1} ------- Role: {2} ------- Date of registration: {3}",
                    variable.Id.ToString(),
                    variable.UserName.ToString(),
                    variable.UserRole.ToString(),
                    variable.DateCreated.ToString(@"yyyy MM dd"));
                    Console.WriteLine("***************************************************************************************************");
                    IDs.Add(variable.Id);
                }
            }
            bool flag1 = false;
            do
            {
                Console.WriteLine("Enter the user id which one you want to delete :)");
                Console.WriteLine("> ");
                input = int.Parse(Console.ReadLine());
                foreach (int el in IDs)
                {
                    if (el == input)
                    {
                        flag1 = true;
                        break;
                    }
                    else
                    {
                        flag1 = false;
                    }
                }
            }
            while (flag1 == false);
            return input;
        }
        public void DeleteUser(int id)
        {

            bool flag = false;
            int input = 0;
            while (flag == false)
            {
                input = UserDelete(id, input);
                using (SqlConnection con = new SqlConnection(_sqlConnectionString))
                {
                    con.Open();
                    using (SqlCommand command = new SqlCommand("DELETE FROM Users WHERE id = '" + input + "'", con))
                    {
                        command.ExecuteNonQuery();
                    }
                    con.Close();
                }
                Console.WriteLine("Operation Successfull.");
                flag = true; break;
            }
        }
        //public void EditUser(int id, string usernamenew, string password, string role)
        //{
        //    connection.Open();
        //    string table = "Update Users set Username = '" + usernamenew + "', Password = '" + password + "', UserRole = '" + role + "'Where id = '" + id + "'";
        //    using (SqlCommand command = new SqlCommand(table, connection))
        //    {
        //        object result = command.ExecuteNonQuery();
        //    }

        //    Console.WriteLine("Connection Successful!");
        //    Console.WriteLine("Press any key.");
        //    Console.ReadKey(true);
        //}
    }
}
