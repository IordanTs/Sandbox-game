﻿using RIDE_3_motorbike_game.HomeMenuView;

namespace RIDE_3_motorbike_game
{
    class Program
    {
        static void Main(string[] args)
        {
            HomeMenu.Run();
        }
    }
}
