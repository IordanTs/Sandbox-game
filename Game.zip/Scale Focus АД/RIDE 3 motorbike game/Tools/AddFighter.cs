﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.Variables;
using RIDE_3_motorbike_game.Information.Fight;
using RIDE_3_motorbike_game.View;

namespace RIDE_3_motorbike_game.Tools
{
    class Create_Fighter
    {
        public void CreateFighter()
        {
            Console.WriteLine("******Create Fighter******");
            Console.WriteLine();
            string Fightername;
            do
            {
                Console.Write("Fighter name: ");
                Fightername = Console.ReadLine();
            }
            while (Verification(Fightername) == true);
            Console.WriteLine();
            Console.WriteLine("Attack Points");
            int Attackpoints = 0;
            Attackpoints = CheckPoints(Attackpoints);
            Console.WriteLine();
            Console.WriteLine("Defence Points");
            int Defencepoints = 0;
            Defencepoints = CheckPoints(Defencepoints);
            Console.WriteLine();
            Console.WriteLine("Health Points");
            int Healthpoints = 0;
            Healthpoints = CheckPoints(Healthpoints);

            var user = maindata.FightersTable();
            int ID;

            if (user == 0)
            {
                ID = 1;
            }
            else
            {
                ID = user + 1;
            }

            FightVariables userdata = new FightVariables()
            {
                Id = ID,
                CharacterName = Fightername,
                AttackPoints = Attackpoints,
                DefencePoints = Defencepoints,
                HealthPoints = Healthpoints,
                DateCreated = DateTime.Now
            };
            maindata.SaveFighter(userdata);
            Console.Clear();
            view.UserView();
        }
        ViewForUserAfterLogIn view = new ViewForUserAfterLogIn();
        private MainDataForFight maindata;
        public Create_Fighter()
        {
            maindata = new MainDataForFight();
        }
        public bool Verification(string user)
        {
            bool flag = false;
            var table = maindata.FightTable();
            if (table == null)
            {
                flag = false;
            }
            else
            {
                for (int i = 1; i < table.Count; i++)
                {
                    if (string.Equals(user, table[i].CharacterName))
                    {
                        Console.WriteLine("This fighter already exist!");
                        flag = true; break;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }
        private int CheckPoints(int n)
        {
            bool f = false;
            do
            {
                Console.WriteLine("Enter value between 0 and 100");
                Console.Write("Points >> ");
                n = int.Parse(Console.ReadLine());
                if (n > 0 && n <= 100)
                {
                    f = true;
                }
                else
                {
                    Console.Write("Error. The value should be in range.");
                    f = false;
                }
            }
            while (f == false);
            return n;
        }
    }
}
