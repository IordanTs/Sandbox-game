﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.Variables;
using RIDE_3_motorbike_game.View;

namespace RIDE_3_motorbike_game.Tools
{
    class AddUser
    {
        // v proches na rabota // ne raboti :)
        //public void AddUserView()
        //{
        //    Console.WriteLine("Enter [a] to continue or [x] to return :)");
        //    Console.Write("> ");
        //    while (true)
        //    {
        //        string UserChoise = Console.ReadLine();
        //        switch (UserChoise)
        //        {
        //            case "a":
        //                {
        //                    Console.Clear();
        //                    AddUser adduser = new AddUser();
        //                    adduser.AddUserr();
        //                    break;
        //                }
        //            case "x":
        //                {
        //                    Console.Clear();
        //                    RIDE_3_motorbike_game.Controller.ViewForUserAfterLogIn.UserView();
        //                    break;
        //                }
        //            default:
        //                Console.WriteLine("Incorect input.");
        //                break;
        //        }
        //    }
        //}
        public void AddUserr()
        {
            ViewForUserAfterLogIn view = new ViewForUserAfterLogIn();
            //AddUserView();
            Console.WriteLine("******Add User******");
            Console.WriteLine();
            string Username;
            do
            {
                Console.Write("Username: ");
                Username = Console.ReadLine();
            }
            while (Verification(Username) == true);
            Console.Write("Password: ");
            string Password = Console.ReadLine();
            Console.WriteLine("Enter role: Options = <<User or Administrator>>");
            Console.Write("Role: ");
            string userrole = Console.ReadLine();

            var user = maindata.Table();
            int ID;

            if (user == 0)
            {
                ID = 1;
            }
            else
            {
                ID = user + 1;
            }

            UserVariables userdata = new UserVariables()
            {
                Id = ID,
                UserName = Username,
                UserPassword = Password,
                UserRole = userrole,
                DateCreated = DateTime.Now
            };
            maindata.SaveUser(userdata);
            Console.Clear();
            view.UserView();
        }
        private MainDataForUser maindata;
        public AddUser()
        {
            maindata = new MainDataForUser();
        }
        public bool Verification(string user)
        {
            bool flag = false;
            var table = maindata.UserTable();
            if (table == null)
            {
                flag = false;
            }
            else
            {
                for (int i = 1; i < table.Count; i++)
                {
                    if (string.Equals(user, table[i].UserName))
                    {
                        Console.WriteLine("This username is already taken!");
                        Console.WriteLine("Please enter another!");
                        flag = true; break;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }
    }
}