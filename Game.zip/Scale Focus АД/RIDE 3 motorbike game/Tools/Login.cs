﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.View;

namespace RIDE_3_motorbike_game.Tools
{
    class Login
    {
        public void UserLogin()
        {
            Console.WriteLine("******Login******");
            Console.WriteLine();
            Console.Write("Username: ");
            string Username = Console.ReadLine();
            Console.Write("Password: ");
            string UserPassword = Console.ReadLine();
            bool userdata = Password(Username, UserPassword);
            Console.Clear();
            if (userdata == true)
            {
                Console.WriteLine("Welcome: " + Username);
                bool userrole = UserRole(Username);
                ViewForUserAfterLogIn userview = new ViewForUserAfterLogIn();
                int user = mainuserdata.IdAndAllData(Username, UserPassword);
                userview.Functions(user);
            }
            else
            {
                Console.WriteLine("Wrong Username or Password!!!");
                Console.WriteLine("Press eney key to continue :)");
                Console.ReadKey(true);
                Console.Clear();
            }
            RIDE_3_motorbike_game.HomeMenuView.HomeMenu.Run();
        }

        private MainDataForUser mainuserdata;
        public Login()
        {
            mainuserdata = new MainDataForUser();
        }
        private bool UserRole(string role)
        {
            bool userrole = false;
            int ID = -1;
            var usertable = mainuserdata.UserTable();
            if (usertable == null)
            {
                Console.WriteLine("NO DATA!!!");
            }
            else
            {
                for (int j = 1; j < usertable.Count; j++)
                {
                    if (string.Equals(role, usertable[j].UserName))
                    {
                        ID = j;
                        break;
                    }
                }
                if (string.Equals("Administrator", usertable[ID].UserRole))
                {
                    userrole = true;
                    Console.WriteLine("Role: Administrator");
                    Console.WriteLine();
                }
                else
                {
                    userrole = false;
                    Console.WriteLine("Role: User");
                    Console.WriteLine();
                }
            }
            return userrole;
        }
        private bool Password(string username, string password)
        {
            bool flag;
            bool UserName = false;
            bool PassWord = false;
            int number = mainuserdata.Table();
            var table = mainuserdata.UserTable();
            if (table == null)
            {
                UserName = false;
                PassWord = false;
                Console.WriteLine("NO DATA!!!");
            }
            else
            {
                for (int i = 0; i < number; i++)
                {
                    if (string.Equals(username, table[i].UserName) && string.Equals(password, table[i].UserPassword.ToString()))
                    {
                        UserName = true;
                        PassWord = true;
                        i = number - 1;
                        
                    }
                    else
                    {
                        UserName = false;
                        PassWord = false;
                        
                    }
                }
            }
            if (UserName == true && PassWord == true)
            {
                flag = true;
            }
            else
            {
                flag = false;
            }
            return flag;
        }
    }
}
