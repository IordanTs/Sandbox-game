﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.Variables;

namespace RIDE_3_motorbike_game.Tools
{
    class Registration
    {
        public void Register()
        {
            Console.WriteLine("******Registration******");
            Console.WriteLine();
            string Username = "";
            do
            {
                Console.Write("Username: ");
                Username = Console.ReadLine();
            }
            while (UserName(Username) == true);
            Console.Write("Password: ");
            string Password = Console.ReadLine();
            Console.WriteLine("Enter role: Options = <<User or Administrator>>");
            Console.Write("Role: ");
            string userrole = Console.ReadLine();

            var maindata = mainuserdata.Table();
            int ID;

            if (maindata == 0)
            {
                ID = 1;
            }
            else
            {
                ID = maindata + 1;
            }

            UserVariables p = new UserVariables()
            {
                Id = ID,
                UserName = Username,
                UserPassword = Password,
                UserRole = userrole,
                DateCreated = DateTime.Now
            };

            mainuserdata.SaveUser(p);
            Console.Clear();
            RIDE_3_motorbike_game.HomeMenuView.HomeMenu.Run();
        }

        private MainDataForUser mainuserdata;
        public Registration()
        {
            mainuserdata = new MainDataForUser();
        }
        public bool UserName(string user)
        {
            bool flag = false;
            var table = mainuserdata.UserTable();
            if (table == null)
            {
                flag = false;
            }
            else
            {
                for (int i = 1; i < table.Count; i++)
                {
                    if (string.Equals(user, table[i].UserName))
                    {
                        Console.WriteLine("Username already exist!!!");
                        flag = true; break;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }
    }
}
