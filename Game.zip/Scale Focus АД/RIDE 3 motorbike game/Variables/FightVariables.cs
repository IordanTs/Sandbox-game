﻿using System;

namespace RIDE_3_motorbike_game.Variables
{
    public class FightVariables
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string CharacterName { get; set; }
        //public string CharacterType { get; set; }
        public int AttackPoints { get; set; }
        public int DefencePoints { get; set; }
        public int HealthPoints { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
