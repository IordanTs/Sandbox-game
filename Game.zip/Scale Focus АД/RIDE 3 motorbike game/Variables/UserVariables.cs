﻿using System;

namespace RIDE_3_motorbike_game.Variables
{
    public class UserVariables
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public string UserRole { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
