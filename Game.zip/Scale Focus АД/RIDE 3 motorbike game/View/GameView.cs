﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.Information.Fight;
using System.Collections.Generic;
using RIDE_3_motorbike_game.Tools;
using RIDE_3_motorbike_game.View;

namespace RIDE_3_motorbike_game.Game
{
    public class GameView
    {
        public void GameVieww()
        {
            Console.WriteLine("Choose an option.");
            Console.WriteLine();
            Console.WriteLine("[C]reate Fighter");
            Console.WriteLine("[F]ighter Table");
            Console.WriteLine("[S]tart a quick battle");
            Console.WriteLine("E[x]it");
            Console.WriteLine();
            Console.Write("> ");
        }
        public void Functions()
        {
            GameVieww();
            while (true)
            {
                string UserChoise = Console.ReadLine();
                switch (UserChoise)
                {
                    case "c":
                        {
                            Console.Clear();
                            Create_Fighter fighter = new Create_Fighter();
                            fighter.CreateFighter();
                            break;
                        }
                    case "f":
                        {
                            Console.Clear();
                            MainDataForFight fighttable = new MainDataForFight();
                            fighttable.FighterViewTable();
                            break;
                        }
                    case "s":
                        {
                            GameMechanics fight = new GameMechanics();
                            fight.StartGame();
                            break;
                        }
                    case "x":
                        {
                            Console.Clear();
                            ViewForUserAfterLogIn userview = new ViewForUserAfterLogIn();
                            userview.UserView();
                            return;
                        }
                    default:
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid command");
                            Console.WriteLine("Press eney key to continue :)");
                            Console.ReadKey(true);
                            Console.Clear();
                            GameVieww();
                            break;
                        }
                }
            }
        }
    }
}
