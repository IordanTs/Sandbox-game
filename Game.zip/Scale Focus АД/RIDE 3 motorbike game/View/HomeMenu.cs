﻿using System;
using RIDE_3_motorbike_game.View;
using RIDE_3_motorbike_game.Tools;

namespace RIDE_3_motorbike_game.HomeMenuView
{
    public class HomeMenu
    {
        public static void Run()
        {
            Console.WriteLine("Home Menu:");
            Console.WriteLine();
            Console.WriteLine("[L]ogin");
            Console.WriteLine("[R]egister");
            Console.WriteLine("E[x]it");
            Console.WriteLine();
            Console.Write("> ");

            while (true)
            {
                var userchoice = Console.ReadLine();
                switch (userchoice)
                {
                    case "l":
                        {
                            Console.Clear();
                            Login login = new Login();
                            login.UserLogin();
                            break;
                        }
                    case "r":
                        {
                            Console.Clear();
                            Registration register = new Registration();
                            register.Register();
                            Console.Clear();
                            break;
                        }
                    case "x":
                        {
                            Console.Clear();
                            Console.WriteLine("Goodbye!");
                            Console.ReadKey(true);
                            return;
                        }
                    default:
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid command");
                            Console.WriteLine("Press eney key to continue :)");
                            Console.ReadKey(true);
                            Console.Clear();
                            Run();
                            return;
                        }
                }
            }
        }
    }
}
