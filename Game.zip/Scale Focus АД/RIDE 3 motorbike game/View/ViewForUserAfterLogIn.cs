﻿using System;
using RIDE_3_motorbike_game.Information;
using RIDE_3_motorbike_game.Information.Fight;
using RIDE_3_motorbike_game.Tools;
using System.Collections.Generic;
using RIDE_3_motorbike_game.Game;

namespace RIDE_3_motorbike_game.View
{
    public class ViewForUserAfterLogIn
    {
        public void UserView()
        {
            Console.WriteLine("Choose an option.");
            Console.WriteLine();
            Console.WriteLine("[A]dd User");
            Console.WriteLine("[E]dit User");
            Console.WriteLine("[D]elete User");
            Console.WriteLine("[U]sers Table");
            Console.WriteLine("[S]tart Game");
            Console.WriteLine("E[x]it");
            Console.WriteLine();
            Console.Write("> ");
        }
        MainDataForUser maindata = new MainDataForUser();
        public void Functions(int id)
        {
            UserView();
            while (true)
            {
                string UserChoise = Console.ReadLine();
                switch (UserChoise)
                {
                    
                    case "a":
                        {
                            Console.Clear();
                            AddUser adduser = new AddUser();
                            adduser.AddUserr();
                            break;
                        }
                    case "u":
                        {
                            Console.Clear();
                            MainDataForUser usertable = new MainDataForUser();
                            usertable.UserViewTable();
                            break;
                        }
                    case "d":
                        {
                            maindata.DeleteUser(id);
                            break;
                        }
                    case "s":
                        {
                            Console.Clear();
                            GameView game = new GameView();
                            game.Functions();
                            break;
                        }
                    case "x":
                        {
                            Console.Clear();
                            return;
                        }
                    //case "e":
                    //    {
                    //        int UserIdChoise = 0;
                    //        UserIdChoise = IDCheck(UserIdChoise);
                    //        string Username;
                    //        do
                    //        {
                    //            Console.WriteLine("Enter new Username.");
                    //            Username = Console.ReadLine();
                    //        }
                    //        while (registration.UserName(Username) == true);
                    //        Console.WriteLine("Enter new Password:");
                    //        string Password = Console.ReadLine();
                    //        string UserRole = Console.ReadLine();
                    //        maindata.EditUser(UserIdChoise, Username, Password, UserRole);
                    //        break;
                    //    }
                    default:
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid command");
                            Console.WriteLine("Press eney key to continue :)");
                            Console.ReadKey(true);
                            Console.Clear();
                            UserView();
                            return;
                        }
                }
            }
        }
        //MainDataForUser usermaindata = new MainDataForUser();
        //public int IDCheck(int usrInputId)
        //{
        //    List<Variables.UserVariables> user = usermaindata.UserTable();
        //    bool flagS = false;
        //    do
        //    {
        //        usermaindata.UserViewTable();
        //        Console.WriteLine();
        //        Console.WriteLine("Enter user id");
        //        usrInputId = int.Parse(Console.ReadLine());
        //        foreach (Variables.UserVariables uservariable in user)
        //        {
        //            if (uservariable.Id == usrInputId)
        //            {
        //                flagS = true;
        //                break;
        //            }
        //            else
        //            {
        //                flagS = false;
        //            }
        //        }
        //    }
        //    while (flagS == true);
        //    return usrInputId;
        //}
    }
}
